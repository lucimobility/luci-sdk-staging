// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from luci_messages:msg/LuciJoystick.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "luci_messages/msg/detail/luci_joystick__rosidl_typesupport_introspection_c.h"
#include "luci_messages/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "luci_messages/msg/detail/luci_joystick__functions.h"
#include "luci_messages/msg/detail/luci_joystick__struct.h"


#ifdef __cplusplus
extern "C"
{
#endif

void LuciJoystick__rosidl_typesupport_introspection_c__LuciJoystick_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  luci_messages__msg__LuciJoystick__init(message_memory);
}

void LuciJoystick__rosidl_typesupport_introspection_c__LuciJoystick_fini_function(void * message_memory)
{
  luci_messages__msg__LuciJoystick__fini(message_memory);
}

static rosidl_typesupport_introspection_c__MessageMember LuciJoystick__rosidl_typesupport_introspection_c__LuciJoystick_message_member_array[2] = {
  {
    "forward_back",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(luci_messages__msg__LuciJoystick, forward_back),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "left_right",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(luci_messages__msg__LuciJoystick, left_right),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers LuciJoystick__rosidl_typesupport_introspection_c__LuciJoystick_message_members = {
  "luci_messages__msg",  // message namespace
  "LuciJoystick",  // message name
  2,  // number of fields
  sizeof(luci_messages__msg__LuciJoystick),
  LuciJoystick__rosidl_typesupport_introspection_c__LuciJoystick_message_member_array,  // message members
  LuciJoystick__rosidl_typesupport_introspection_c__LuciJoystick_init_function,  // function to initialize message memory (memory has to be allocated)
  LuciJoystick__rosidl_typesupport_introspection_c__LuciJoystick_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t LuciJoystick__rosidl_typesupport_introspection_c__LuciJoystick_message_type_support_handle = {
  0,
  &LuciJoystick__rosidl_typesupport_introspection_c__LuciJoystick_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_luci_messages
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, luci_messages, msg, LuciJoystick)() {
  if (!LuciJoystick__rosidl_typesupport_introspection_c__LuciJoystick_message_type_support_handle.typesupport_identifier) {
    LuciJoystick__rosidl_typesupport_introspection_c__LuciJoystick_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &LuciJoystick__rosidl_typesupport_introspection_c__LuciJoystick_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
