// generated from rosidl_generator_c/resource/idl.h.em
// with input from luci_messages:msg/LuciJoystick.idl
// generated code does not contain a copyright notice

#ifndef LUCI_MESSAGES__MSG__LUCI_JOYSTICK_H_
#define LUCI_MESSAGES__MSG__LUCI_JOYSTICK_H_

#include "luci_messages/msg/detail/luci_joystick__struct.h"
#include "luci_messages/msg/detail/luci_joystick__functions.h"
#include "luci_messages/msg/detail/luci_joystick__type_support.h"

#endif  // LUCI_MESSAGES__MSG__LUCI_JOYSTICK_H_
