// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef LUCI_MESSAGES__MSG__LUCI_JOYSTICK_HPP_
#define LUCI_MESSAGES__MSG__LUCI_JOYSTICK_HPP_

#include "luci_messages/msg/detail/luci_joystick__struct.hpp"
#include "luci_messages/msg/detail/luci_joystick__builder.hpp"
#include "luci_messages/msg/detail/luci_joystick__traits.hpp"

#endif  // LUCI_MESSAGES__MSG__LUCI_JOYSTICK_HPP_
