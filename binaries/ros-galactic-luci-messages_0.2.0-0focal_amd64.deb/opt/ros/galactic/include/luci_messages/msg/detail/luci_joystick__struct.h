// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from luci_messages:msg/LuciJoystick.idl
// generated code does not contain a copyright notice

#ifndef LUCI_MESSAGES__MSG__DETAIL__LUCI_JOYSTICK__STRUCT_H_
#define LUCI_MESSAGES__MSG__DETAIL__LUCI_JOYSTICK__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Struct defined in msg/LuciJoystick in the package luci_messages.
typedef struct luci_messages__msg__LuciJoystick
{
  int32_t forward_back;
  int32_t left_right;
} luci_messages__msg__LuciJoystick;

// Struct for a sequence of luci_messages__msg__LuciJoystick.
typedef struct luci_messages__msg__LuciJoystick__Sequence
{
  luci_messages__msg__LuciJoystick * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} luci_messages__msg__LuciJoystick__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // LUCI_MESSAGES__MSG__DETAIL__LUCI_JOYSTICK__STRUCT_H_
