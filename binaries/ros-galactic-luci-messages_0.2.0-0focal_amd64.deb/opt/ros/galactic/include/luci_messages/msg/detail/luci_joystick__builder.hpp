// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from luci_messages:msg/LuciJoystick.idl
// generated code does not contain a copyright notice

#ifndef LUCI_MESSAGES__MSG__DETAIL__LUCI_JOYSTICK__BUILDER_HPP_
#define LUCI_MESSAGES__MSG__DETAIL__LUCI_JOYSTICK__BUILDER_HPP_

#include "luci_messages/msg/detail/luci_joystick__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace luci_messages
{

namespace msg
{

namespace builder
{

class Init_LuciJoystick_left_right
{
public:
  explicit Init_LuciJoystick_left_right(::luci_messages::msg::LuciJoystick & msg)
  : msg_(msg)
  {}
  ::luci_messages::msg::LuciJoystick left_right(::luci_messages::msg::LuciJoystick::_left_right_type arg)
  {
    msg_.left_right = std::move(arg);
    return std::move(msg_);
  }

private:
  ::luci_messages::msg::LuciJoystick msg_;
};

class Init_LuciJoystick_forward_back
{
public:
  Init_LuciJoystick_forward_back()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_LuciJoystick_left_right forward_back(::luci_messages::msg::LuciJoystick::_forward_back_type arg)
  {
    msg_.forward_back = std::move(arg);
    return Init_LuciJoystick_left_right(msg_);
  }

private:
  ::luci_messages::msg::LuciJoystick msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::luci_messages::msg::LuciJoystick>()
{
  return luci_messages::msg::builder::Init_LuciJoystick_forward_back();
}

}  // namespace luci_messages

#endif  // LUCI_MESSAGES__MSG__DETAIL__LUCI_JOYSTICK__BUILDER_HPP_
