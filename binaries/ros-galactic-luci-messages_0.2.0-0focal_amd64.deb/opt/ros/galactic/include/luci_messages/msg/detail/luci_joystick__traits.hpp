// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from luci_messages:msg/LuciJoystick.idl
// generated code does not contain a copyright notice

#ifndef LUCI_MESSAGES__MSG__DETAIL__LUCI_JOYSTICK__TRAITS_HPP_
#define LUCI_MESSAGES__MSG__DETAIL__LUCI_JOYSTICK__TRAITS_HPP_

#include "luci_messages/msg/detail/luci_joystick__struct.hpp"
#include <stdint.h>
#include <rosidl_runtime_cpp/traits.hpp>
#include <sstream>
#include <string>
#include <type_traits>

namespace rosidl_generator_traits
{

inline void to_yaml(
  const luci_messages::msg::LuciJoystick & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: forward_back
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "forward_back: ";
    value_to_yaml(msg.forward_back, out);
    out << "\n";
  }

  // member: left_right
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "left_right: ";
    value_to_yaml(msg.left_right, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const luci_messages::msg::LuciJoystick & msg)
{
  std::ostringstream out;
  to_yaml(msg, out);
  return out.str();
}

template<>
inline const char * data_type<luci_messages::msg::LuciJoystick>()
{
  return "luci_messages::msg::LuciJoystick";
}

template<>
inline const char * name<luci_messages::msg::LuciJoystick>()
{
  return "luci_messages/msg/LuciJoystick";
}

template<>
struct has_fixed_size<luci_messages::msg::LuciJoystick>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<luci_messages::msg::LuciJoystick>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<luci_messages::msg::LuciJoystick>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // LUCI_MESSAGES__MSG__DETAIL__LUCI_JOYSTICK__TRAITS_HPP_
